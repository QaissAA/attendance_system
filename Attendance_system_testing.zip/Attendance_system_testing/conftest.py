import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import logging

# Логгер
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

@pytest.fixture
def browser():
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--window-size=1920,1080")
    driver = webdriver.Chrome(options=options)
    logger.info("Browser launched")
    yield driver
    logger.info("Closing browser")
    driver.quit()

# Фикстура для скриншотов при падении
@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # Запускаем тест и получаем результат
    outcome = yield
    rep = outcome.get_result()

    if rep.when == "call" and rep.failed:
        # Получаем фикстуру браузера
        browser = item.funcargs.get("browser")
        if browser:
            screenshot_dir = os.path.join(os.getcwd(), "screenshots")
            os.makedirs(screenshot_dir, exist_ok=True)
            file_name = f"{item.name}.png"
            path = os.path.join(screenshot_dir, file_name)
            browser.save_screenshot(path)
            logging.info(f"Screenshot saved: {path}")
