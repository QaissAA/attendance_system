from locust import HttpUser, task, between
import random
import string

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:116.0) Gecko/20100101 Firefox/116.0",
]

def random_text(length):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

class AttendanceUser(HttpUser):
    host = "http://localhost:5000"
    wait_time = between(1, 3)

    def on_start(self):
        self.headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.attendance_ids = []

    @task(3)
    def mark_attendance(self):
        payload = {
            "date": "2025-05-15",
            "status": random.choice(["Present", "Absent", "Late"]),
            "student_id": random.randint(1, 1000),
        }
        with self.client.post(
            "/api/attendance",
            json=payload,
            headers=self.headers,
            name="POST /api/attendance",
            catch_response=True
        ) as resp:
            if resp.status_code == 201 and "id" in resp.json():
                self.attendance_ids.append(resp.json()["id"])

    @task(2)
    def get_attendance_list(self):
        with self.client.get(
            "/api/attendance",
            headers=self.headers,
            name="GET /api/attendance",
            catch_response=True
        ) as resp:
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    self.attendance_ids = [item["_id"] for item in data]
                except Exception as e:
                    resp.failure(f"Invalid JSON or structure: {e}")

    @task(1)
    def update_attendance(self):
        if not self.attendance_ids:
            return
        random_id = random.choice(self.attendance_ids)
        payload = {
            "status": random.choice(["Present", "Absent", "Late"]),
        }
        self.client.put(
            f"/api/attendance/{random_id}",
            json=payload,
            headers=self.headers,
            name="PUT /api/attendance/[id]"
        )

    @task(1)
    def delete_attendance(self):
        if not self.attendance_ids:
            return
        random_id = self.attendance_ids.pop()
        self.client.delete(
            f"/api/attendance/{random_id}",
            headers=self.headers,
            name="DELETE /api/attendance/[id]"
        )
