import os
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains
from datetime import date

def test_select_attendance_status(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    # Авторизация
    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()
    time.sleep(1)

    # Отметка посещаемости с использованием Select class
    today = date.today().strftime("%Y-%m-%d")
    browser.find_element(By.ID, "attendance-date").send_keys(today)

    select_elem = Select(browser.find_element(By.ID, "attendance-status"))
    select_elem.select_by_visible_text("Absent")  # ⬅ Пример использования Select class

    browser.find_element(By.XPATH, "//button[text()='Submit']").click()
    time.sleep(1)

    rows = browser.find_elements(By.XPATH, "//table[@id='attendance-table']/tr")
    assert any("Absent" in row.text and today in row.text for row in rows)

def test_hover_username(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    # Авторизация
    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()
    time.sleep(1)

    # Наведение на имя пользователя (можно добавить title/tooltip в HTML)
    user_label = browser.find_element(By.ID, "user-label")
    ActionChains(browser).move_to_element(user_label).perform()

    # Здесь можно добавить проверку всплывающего текста (если будет добавлен title/tooltip)
    assert user_label.is_displayed()
