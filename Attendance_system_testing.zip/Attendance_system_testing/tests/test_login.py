import os
import time
from selenium.webdriver.common.by import By

def test_valid_login(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    time.sleep(1)
    user_label = browser.find_element(By.ID, "user-label").text
    assert user_label == "student", "Valid login failed"

def test_invalid_login(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    browser.find_element(By.ID, "username").send_keys("wrong")
    browser.find_element(By.ID, "password").send_keys("wrongpass")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    time.sleep(1)
    msg = browser.find_element(By.ID, "login-msg").text
    assert msg == "Invalid login!", "Invalid login not detected"
