import os
import time
from selenium.webdriver.common.by import By
from datetime import date

def test_mark_attendance(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    # Авторизация
    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    time.sleep(1)

    # Отметка посещаемости на сегодня
    today = date.today().strftime("%Y-%m-%d")
    date_input = browser.find_element(By.ID, "attendance-date")
    status_select = browser.find_element(By.ID, "attendance-status")
    submit_btn = browser.find_element(By.XPATH, "//button[text()='Submit']")

    date_input.send_keys(today)
    status_select.click()
    status_select.find_element(By.XPATH, "//option[text()='Present']").click()
    submit_btn.click()

    time.sleep(1)

    # Проверка, что запись появилась в таблице
    rows = browser.find_elements(By.XPATH, "//table[@id='attendance-table']/tr")
    assert any(today in row.text for row in rows), "Attendance was not marked"
