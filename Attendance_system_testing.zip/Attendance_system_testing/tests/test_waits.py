import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import Select
import time

def test_implicit_wait(browser):
    browser.implicitly_wait(5)  # ⏳ глобальное ожидание

    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    # элемент должен появиться — ждём благодаря implicit wait
    user_label = browser.find_element(By.ID, "user-label")
    assert user_label.text == "student"

def test_explicit_wait(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    try:
        wait = WebDriverWait(browser, 10)
        user_label = wait.until(EC.visibility_of_element_located((By.ID, "user-label")))
        assert user_label.text == "student"
    except TimeoutException:
        assert False, "User label did not appear in time"

def test_fluent_wait(browser):
    file_path = f"file://{os.getcwd()}/app/index.html"
    browser.get(file_path)

    browser.find_element(By.ID, "username").send_keys("student")
    browser.find_element(By.ID, "password").send_keys("1234")
    browser.find_element(By.XPATH, "//button[text()='Login']").click()

    wait = WebDriverWait(browser, timeout=10, poll_frequency=0.5)
    user_label = wait.until(EC.presence_of_element_located((By.ID, "user-label")))
    assert user_label.text == "student"
