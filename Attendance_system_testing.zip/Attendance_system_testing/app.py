from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api/attendance', methods=['POST'])
def mark_attendance():
    data = request.json
    # Можно валидировать данные тут
    if data.get("username") == "student" and data.get("status") in ["Present", "Absent"]:
        return jsonify({"success": True, "message": "Attendance marked"})
    else:
        return jsonify({"success": False, "message": "Invalid data"}), 400

if __name__ == "__main__":
    app.run(port=5000)
# Запуск приложения
# python app.py